# LocalAIAssistant (Android)

Каркас локального самообучающегося ИИ-ассистента для Android на базе Kotlin, Jetpack Compose, Room и AccessibilityService.

## Структура проекта
- `app/src/main/java/com/localai/assistant/MainActivity.kt` — интерфейс чата, управление обучением и обратная связь (`👍` / `👎`).
- `app/src/main/java/com/localai/assistant/service/AIAssistantAccessibilityService.kt` — чтение иерархии экрана и выполнение кликов.
- `app/src/main/java/com/localai/assistant/learning/SkillRecorder.kt` — запись действий пользователя в JSON-макросы.
- `app/src/main/java/com/localai/assistant/memory/MemoryDatabase.kt` — локальная БД Room для хранения фактов, кода и навыков.
- `app/src/main/java/com/localai/assistant/memory/LocalVectorEngine.kt` — семантический поиск по накопленному опыту.
- `app/src/main/java/com/localai/assistant/engine/CodeExecutionEngine.kt` — библиотека и менеджер пользовательских скриптов.

## Запуск в Android Studio
1. Распакуйте архив и откройте папку `LocalAIAssistant` в Android Studio (Iguana / Jellyfish / Koala или новее).
2. Дождитесь синхронизации Gradle.
3. Соберите и установите приложение на Android-устройство (API 26+).
4. Нажмите **«Доступ к экрану»** в приложении и активируйте службу **Local AI Assistant** в разделе *Специальные возможности*.
