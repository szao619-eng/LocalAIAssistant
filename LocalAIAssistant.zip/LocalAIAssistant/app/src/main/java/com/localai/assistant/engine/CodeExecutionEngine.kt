package com.localai.assistant.engine

import java.io.File

class CodeExecutionEngine(private val filesDir: File) {

    private val libraryDir = File(filesDir, "ai_code_library").apply { mkdirs() }

    fun saveAndPrepareScript(name: String, code: String, language: String): Result<File> {
        return try {
            val ext = when (language.lowercase()) {
                "python", "py" -> "py"
                "kotlin", "kt" -> "kt"
                "javascript", "js" -> "js"
                else -> "txt"
            }
            val safeName = name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val scriptFile = File(libraryDir, "$safeName.$ext")
            scriptFile.writeText(code)
            Result.success(scriptFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun listSavedScripts(): List<File> {
        return libraryDir.listFiles()?.toList() ?: emptyList()
    }
}
