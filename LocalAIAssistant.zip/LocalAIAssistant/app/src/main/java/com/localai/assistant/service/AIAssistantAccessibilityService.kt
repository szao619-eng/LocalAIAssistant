package com.localai.assistant.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.localai.assistant.learning.SkillRecorder

class AIAssistantAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AIAssistantAccessibilityService? = null
            private set
        val skillRecorder = SkillRecorder()
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.let {
            skillRecorder.onUserAction(it)
        }
    }

    override fun onInterrupt() {
        instance = null
    }

    fun clickByText(text: String): Boolean {
        val rootNode: AccessibilityNodeInfo = rootInActiveWindow ?: return false
        val nodes = rootNode.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else {
                var parent = node.parent
                while (parent != null) {
                    if (parent.isClickable) {
                        return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    parent = parent.parent
                }
            }
        }
        return false
    }

    fun getScreenHierarchySummary(): String {
        val root = rootInActiveWindow ?: return "Экран недоступен"
        val sb = StringBuilder()
        traverseNode(root, 0, sb)
        return sb.toString()
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, depth: Int, sb: StringBuilder) {
        if (node == null) return
        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()
        if (!text.isNullOrBlank() || !desc.isNullOrBlank()) {
            sb.append("  ".repeat(depth))
            sb.append("[${node.className?.toString()?.substringAfterLast('.')}] ")
            if (!text.isNullOrBlank()) sb.append("text='$text' ")
            if (!desc.isNullOrBlank()) sb.append("desc='$desc' ")
            if (node.isClickable) sb.append("(clickable)")
            sb.append("\n")
        }
        for (i in 0 until node.childCount) {
            traverseNode(node.getChild(i), depth + 1, sb)
        }
    }
}
