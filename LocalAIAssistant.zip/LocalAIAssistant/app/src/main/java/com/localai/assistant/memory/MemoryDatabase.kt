package com.localai.assistant.memory

import android.content.Context
import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class FloatArrayConverter {
    @TypeConverter
    fun fromFloatArray(array: FloatArray): String = Gson().toJson(array)

    @TypeConverter
    fun toFloatArray(json: String): FloatArray {
        val type = object : TypeToken<FloatArray>() {}.type
        return Gson().fromJson(json, type) ?: FloatArray(0)
    }
}

@Entity(tableName = "learned_memories")
data class MemoryItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String,      // "fact", "code_snippet", "ui_skill", "mistake"
    val trigger: String,
    val content: String,
    val embedding: FloatArray,
    val successScore: Int = 1,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface MemoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMemory(item: MemoryItem): Long

    @Query("SELECT * FROM learned_memories WHERE category = :category ORDER BY successScore DESC")
    suspend fun getByCategory(category: String): List<MemoryItem>

    @Query("SELECT * FROM learned_memories")
    suspend fun getAllMemories(): List<MemoryItem>

    @Query("UPDATE learned_memories SET successScore = successScore + 1 WHERE id = :id")
    suspend fun reinforceMemory(id: Int)

    @Query("UPDATE learned_memories SET successScore = successScore - 1 WHERE id = :id")
    suspend fun penalizeMemory(id: Int)
}

@Database(entities = [MemoryItem::class], version = 1, exportSchema = false)
@TypeConverters(FloatArrayConverter::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "local_ai_memory.db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
