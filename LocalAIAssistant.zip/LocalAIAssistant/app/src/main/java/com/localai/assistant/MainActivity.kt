package com.localai.assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.localai.assistant.engine.CodeExecutionEngine
import com.localai.assistant.memory.AppDatabase
import com.localai.assistant.memory.LocalVectorEngine
import com.localai.assistant.service.AIAssistantAccessibilityService
import kotlinx.coroutines.launch

data class ChatMessage(
    val sender: String,
    val text: String,
    val memoryId: Int? = null
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.getDatabase(this)
        val vectorEngine = LocalVectorEngine(db.memoryDao())
        val codeEngine = CodeExecutionEngine(filesDir)

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AssistantScreen(
                        db = db,
                        vectorEngine = vectorEngine,
                        codeEngine = codeEngine
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(
    db: AppDatabase,
    vectorEngine: LocalVectorEngine,
    codeEngine: CodeExecutionEngine
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var messageText by remember { mutableStateOf("") }
    var isRecordingSkill by remember { mutableStateOf(false) }
    var pendingSkillName by remember { mutableStateOf("") }

    val chatHistory = remember {
        mutableStateListOf(
            ChatMessage(
                "Агент",
                "Локальный ИИ-ассистент запущен. Доступны: управление экраном, библиотека кода и самообучение.\n" +
                "Команды:\n" +
                "• 'открой <текст>' — клик по элементу экрана\n" +
                "• 'запомни: <триггер> = <знание>' — обучение факту\n" +
                "• 'код: <имя> | <код>' — сохранение скрипта в библиотеку\n" +
                "• 'экран' — анализ текущего интерфейса"
            )
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Верхняя панель инструментов
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(
                onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Доступ к экрану", maxLines = 1)
            }

            Button(
                onClick = {
                    val recorder = AIAssistantAccessibilityService.skillRecorder
                    if (!isRecordingSkill) {
                        recorder.startRecording()
                        isRecordingSkill = true
                        chatHistory.add(ChatMessage("Система", "Запись действий начата. Выполните нужные нажатия на телефоне и нажмите 'Стоп'."))
                    } else {
                        val serialized = recorder.stopAndSerialize()
                        isRecordingSkill = false
                        val skillTrigger = pendingSkillName.ifBlank { "Пользовательский сценарий #${System.currentTimeMillis() % 1000}" }
                        scope.launch {
                            val id = vectorEngine.learn("ui_skill", skillTrigger, serialized)
                            chatHistory.add(ChatMessage("Агент", "Навык '$skillTrigger' изучен и сохранён в память!", id.toInt()))
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecordingSkill) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text(if (isRecordingSkill) "Стоп запись" else "Обучить кликам", maxLines = 1)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // История чата
        LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
            items(chatHistory) { msg ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (msg.sender == "Вы") MaterialTheme.colorScheme.primaryContainer
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = msg.sender, style = MaterialTheme.typography.labelMedium)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = msg.text, style = MaterialTheme.typography.bodyMedium)
                        if (msg.memoryId != null) {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                TextButton(onClick = {
                                    scope.launch { db.memoryDao().reinforceMemory(msg.memoryId) }
                                }) { Text("👍 Полезно") }
                                TextButton(onClick = {
                                    scope.launch { db.memoryDao().penalizeMemory(msg.memoryId) }
                                }) { Text("👎 Ошибка") }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Ввод запроса
        Row(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = messageText,
                onValueChange = { messageText = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Введите задачу или команду...") }
            )
            Button(
                onClick = {
                    if (messageText.isNotBlank()) {
                        val prompt = messageText.trim()
                        chatHistory.add(ChatMessage("Вы", prompt))
                        messageText = ""

                        scope.launch {
                            when {
                                prompt.startsWith("запомни:", ignoreCase = true) -> {
                                    val body = prompt.substringAfter(":").trim()
                                    val parts = body.split("=", limit = 2)
                                    if (parts.size == 2) {
                                        val id = vectorEngine.learn("fact", parts[0].trim(), parts[1].trim())
                                        chatHistory.add(ChatMessage("Агент", "Запомнил: '${parts[0].trim()}' -> '${parts[1].trim()}'", id.toInt()))
                                    } else {
                                        chatHistory.add(ChatMessage("Агент", "Формат: запомни: вопрос = ответ"))
                                    }
                                }

                                prompt.startsWith("код:", ignoreCase = true) -> {
                                    val body = prompt.substringAfter(":").trim()
                                    val parts = body.split("|", limit = 2)
                                    val name = parts.getOrNull(0)?.trim() ?: "script"
                                    val code = parts.getOrNull(1)?.trim() ?: body
                                    val res = codeEngine.saveAndPrepareScript(name, code, "kt")
                                    res.onSuccess { file ->
                                        val id = vectorEngine.learn("code_snippet", name, code)
                                        chatHistory.add(ChatMessage("Агент", "Скрипт сохранён в библиотеку: ${file.name}", id.toInt()))
                                    }.onFailure { err ->
                                        chatHistory.add(ChatMessage("Агент", "Ошибка сохранения кода: ${err.message}"))
                                    }
                                }

                                prompt.equals("экран", ignoreCase = true) -> {
                                    val summary = AIAssistantAccessibilityService.instance?.getScreenHierarchySummary()
                                        ?: "Служба Accessibility не включена в настройках телефона."
                                    chatHistory.add(ChatMessage("Агент", "Структура экрана:\n$summary"))
                                }

                                prompt.startsWith("открой ", ignoreCase = true) -> {
                                    val target = prompt.substringAfter(" ").trim()
                                    val ok = AIAssistantAccessibilityService.instance?.clickByText(target) == true
                                    chatHistory.add(ChatMessage("Агент", if (ok) "Нажал на '$target'" else "Не удалось найти '$target' (проверьте Accessibility)"))
                                }

                                else -> {
                                    val memories = vectorEngine.recallRelevantExperience(prompt)
                                    if (memories.isNotEmpty()) {
                                        val top = memories.first()
                                        chatHistory.add(
                                            ChatMessage(
                                                "Агент (Память [${top.category}])",
                                                "Найдено в опыте (рейтинг ${top.successScore}):\n${top.content}",
                                                top.id
                                            )
                                        )
                                    } else {
                                        pendingSkillName = prompt
                                        chatHistory.add(
                                            ChatMessage(
                                                "Агент",
                                                "В локальной памяти пока нет готового решения для '$prompt'. " +
                                                "Вы можете нажать 'Обучить кликам' и показать последовательность действий или добавить правило через 'запомни:'."
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Пуск")
            }
        }
    }
}
