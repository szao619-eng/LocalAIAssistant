package com.localai.assistant.learning

import android.view.accessibility.AccessibilityEvent
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class RecordedStep(
    val packageName: String,
    val actionType: Int,
    val targetText: String?,
    val viewId: String?,
    val delayMs: Long
)

class SkillRecorder {
    var isRecording: Boolean = false
        private set

    private val steps = mutableListOf<RecordedStep>()
    private var lastEventTime = 0L

    fun startRecording() {
        steps.clear()
        isRecording = true
        lastEventTime = System.currentTimeMillis()
    }

    fun onUserAction(event: AccessibilityEvent) {
        if (!isRecording) return
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val now = System.currentTimeMillis()
            val source = event.source
            steps.add(
                RecordedStep(
                    packageName = event.packageName?.toString() ?: "",
                    actionType = event.eventType,
                    targetText = source?.text?.toString(),
                    viewId = source?.viewIdResourceName,
                    delayMs = now - lastEventTime
                )
            )
            lastEventTime = now
        }
    }

    fun stopAndSerialize(): String {
        isRecording = false
        return Gson().toJson(steps)
    }

    companion object {
        fun deserialize(json: String): List<RecordedStep> {
            val type = object : TypeToken<List<RecordedStep>>() {}.type
            return Gson().fromJson(json, type) ?: emptyList()
        }
    }
}
