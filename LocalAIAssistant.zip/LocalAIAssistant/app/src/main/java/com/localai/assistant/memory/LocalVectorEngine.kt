package com.localai.assistant.memory

import kotlin.math.sqrt

class LocalVectorEngine(private val dao: MemoryDao) {

    // Простой локальный хеш-эмбеддер как fallback, если модель MediaPipe ещё не загружена в assets
    fun computeLocalEmbedding(text: String, dim: Int = 128): FloatArray {
        val vec = FloatArray(dim)
        val tokens = text.lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        for (token in tokens) {
            val idx = (token.hashCode() and 0x7FFFFFFF) % dim
            vec[idx] += 1.0f
        }
        val norm = sqrt(vec.sumOf { (it * it).toDouble() }).toFloat()
        if (norm > 0f) {
            for (i in vec.indices) vec[i] /= norm
        }
        return vec
    }

    private fun cosineSimilarity(vecA: FloatArray, vecB: FloatArray): Float {
        if (vecA.size != vecB.size || vecA.isEmpty()) return 0f
        var dotProduct = 0.0f
        var normA = 0.0f
        var normB = 0.0f
        for (i in vecA.indices) {
            dotProduct += vecA[i] * vecB[i]
            normA += vecA[i] * vecA[i]
            normB += vecB[i] * vecB[i]
        }
        return if (normA == 0f || normB == 0f) 0f else dotProduct / (sqrt(normA) * sqrt(normB))
    }

    suspend fun learn(category: String, trigger: String, content: String): Long {
        val emb = computeLocalEmbedding(trigger)
        return dao.saveMemory(
            MemoryItem(
                category = category,
                trigger = trigger,
                content = content,
                embedding = emb
            )
        )
    }

    suspend fun recallRelevantExperience(query: String, threshold: Float = 0.35f): List<MemoryItem> {
        val queryEmbedding = computeLocalEmbedding(query)
        return dao.getAllMemories()
            .filter { it.successScore > 0 }
            .map { item -> item to cosineSimilarity(queryEmbedding, item.embedding) }
            .filter { it.second >= threshold }
            .sortedByDescending { it.second * (1 + it.first.successScore * 0.1f) }
            .take(3)
            .map { it.first }
    }
}
